<?php
    header("Location: ../index.php");
	die();

?>
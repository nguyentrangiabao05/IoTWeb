<div id="page-content-wrapper">
<div class="container-fluid">
<div class="row">
    <div class="col-lg-12">
        <section class="content-header">
            <h1>
                Configuration <small>documentation</small>
            </h1>
        </section>
    </div>
</div>
<div class="spacer"></div>
<div class="row">
    <div class="col-md-6">
        <?php
            //echo '<a href="?mod=' . $module . '&menu=' . $menu . '&add_menu=true" class="btn btn-success btn-sm" role="button">Add menu</a>';
        ?>        
    </div>
</div><!--/row-->
<hr class="style-four">
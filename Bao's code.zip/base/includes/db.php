<?php
include_once('constants.php');
error_reporting(0);
$con = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DATABASE);

?>
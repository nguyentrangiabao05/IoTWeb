<div class="user-panel">
    <div class="image pull-left">
        <a href=""><img src="../base/img/rocket.png" class="img-circle" alt="User Image"></a>
    </div>
    <div class="slogan pull-right">
        <h3 class="pull-left">Hệ thống IoT</h3>
        <br>
        <h5 class="pull-left">Vạn Vật Kết Nối</h5>
    </div>
</div>
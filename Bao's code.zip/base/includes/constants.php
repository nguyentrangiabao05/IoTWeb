<?php
define('DB_HOST',' ');
define('DB_USER',' ');
define('DB_PASS',' ');
define('DATABASE',' ');
?>